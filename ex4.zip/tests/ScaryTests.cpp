//
// Created by orerez on 04/07/2017.
//

#include "../mtmtest.h"
#include "../EscapeRoomWrapper.h"
#include "../ScaryRoom.h"
#include "../Exceptions.h"

using namespace mtm::escaperoom;

static bool scaryBaseFunctions(){
    ScaryRoom room=ScaryRoom((char*)"firstRoom",50,5,4,16,7);
    ASSERT_EQUALS(7,room.getNumOfScaryEnigmas());
    ASSERT_NO_THROW(room.setNewAgeLimit(14));
    ASSERT_NO_THROW(room.incNumberOfScaryEnigmas());
    ASSERT_EQUALS(8,room.getNumOfScaryEnigmas());
    ASSERT_THROWS(ScaryRoomIllegalAgeLimit,room.setNewAgeLimit(-3));
    return true;
}

int ScaryTests(){
    RUN_TEST(scaryBaseFunctions);
    return 0;
}