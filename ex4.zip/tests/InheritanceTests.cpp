//
// Created by orerez on 01/07/2017.
//


#include "../mtmtest.h"
#include "../EscapeRoomWrapper.h"
#include "../ScaryRoom.h"
#include "../Exceptions.h"
#include "../KidsRoom.h"

using namespace mtm::escaperoom;

static bool scaryBaseFunctions(){
    ScaryRoom room=ScaryRoom((char*)"firstRoom",50,5,4,16,7);
    ASSERT_EQUALS(7,room.getNumOfScaryEnigmas());
    ASSERT_NO_THROW(room.setNewAgeLimit(14));
    ASSERT_NO_THROW(room.incNumberOfScaryEnigmas());
    ASSERT_EQUALS(8,room.getNumOfScaryEnigmas());
    ASSERT_THROWS(ScaryRoomIllegalAgeLimit,room.setNewAgeLimit(-3));
    return true;
}
static bool kidsBaseFunctions(){
    KidsRoom room=KidsRoom((char*)"firstRoom",50,5,4,7);
    ASSERT_NO_THROW(room.setNewAgeLimit(3));
    ASSERT_THROWS(mtm::escaperoom::KidsRoomIllegalAgeLimit,room.setNewAgeLimit(-3));
    return true;
}
int InheriTests(){
    RUN_TEST(scaryBaseFunctions);
    RUN_TEST(kidsBaseFunctions);
    return 0;
}