//
// Created by orerez on 01/07/2017.
//

#include <set>
#include <iostream>
#include <cstring>
#include "../mtmtest.h"
#include <assert.h>
#include "../Enigma.h"
#include "../Exceptions.h"

using namespace mtm::escaperoom;

using std::string;
using std::set;
using mtm::escaperoom::Enigma;

static bool enigmaBasicFunctions(){
    set<string> elements;
    ASSERT_NO_THROW(elements.insert("map"));
    ASSERT_NO_THROW(elements.insert("pen"));
    ASSERT_NO_THROW(elements.insert("clock"));
    ASSERT_NO_THROW(elements.insert("lock"));
    ASSERT_NO_THROW(elements.insert("key"));
    Enigma basic("Empty",(Difficulty)3);
    ASSERT_NO_THROW(basic.addElement("hat"));
    ASSERT_NO_THROW(basic.addElement("hat"));
    if(basic.getSetOfElements().size()!=1 || basic.getNumOfElements()!=1)
        return false;
    ASSERT_THROWS(EnigmaElementNotFoundException,basic.removeElement("boom"));
    ASSERT_NO_THROW(basic.removeElement("hat"));
    if(basic.getSetOfElements().size()!=0 || basic.getNumOfElements()!=0)
        return false;
    ASSERT_THROWS(EnigmaNoElementsException,basic.removeElement("key"));
    try { Enigma enigma("allan",(Difficulty)0,1,elements); }
    catch( EnigmaIllegalSizeParamException illegalSizeParamException){ std::cout<<"Wrong set size!"<<std::endl; }
    Enigma enigma("allan",(Difficulty)0,5,elements);
    Enigma enigma1=enigma;
    Enigma enigma2(enigma1);
    std::cout<<"compute will now print 3 identical enigma from different constructors\n"
             <<enigma<<enigma1<<enigma2<<std::endl;
    ASSERT_EQUALS("allan",enigma.getName());
    ASSERT_EQUALS((Difficulty)0,enigma1.getDifficulty());
    ASSERT_EQUALS(enigma2,enigma1);
    ASSERT_EQUALS(true,enigma1.areEqualyComplex(enigma2));
    ASSERT_EQUALS(elements,enigma.getSetOfElements());
    set<string> more_elements;
    ASSERT_NO_THROW(more_elements.insert("budha sculpture"));
    ASSERT_NO_THROW(more_elements.insert("KFC Chicken"));
    Enigma enigma3("bobo",(Difficulty)1,2,more_elements);
    if(enigma3<enigma1||enigma3<enigma2)
        return false;
    return(enigma3!=enigma2);
}

int Enigma_Tests(){
    RUN_TEST(enigmaBasicFunctions);
    return 0;
}