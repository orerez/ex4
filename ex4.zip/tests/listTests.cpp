#include <ostream>
#include <iostream>
//
// Created by orerez on 01/07/2017.
//
#include <iostream>
#include <assert.h>
#include "../list.h"
#include "../mtmtest.h"

using std::string;

typedef string T;

class HasSameName{
    string name;
public:
    HasSameName(string name) : name(name) {}
    bool operator()(string node_name) const {
        return node_name == this->name;
    }
};

class StringIsSmaller{
public:
    StringIsSmaller() {}
    bool operator()(const string& string1 ,const string& string2) const {
        return string1 < string2;
    }
};

static bool checkContent(List<T>::Iterator iterator){
    ASSERT_EQUALS("Alfy",iterator.getNode().getInfo());
    ASSERT_EQUALS("Dolev Shifris",(++iterator).getNode().getInfo());
    ASSERT_EQUALS("Gury",(++iterator).getNode().getInfo());
    ASSERT_EQUALS("avraham",(++iterator).getNode().getInfo());
    return true;
}

static bool nodeBasic(){
    std::cout<<"hello"<<std::endl;
    node<T> node1, node2,node3;
    node1.setInfo("hi there");
    node2.setInfo("bro");
    node3.setInfo("dododo");
    T n1,n2,n3;
    n1=node1.getInfo();
    n2=node2.getInfo();
    n3=node3.getInfo();
    assert(n1=="hi there" && n2=="bro" && n3=="dododo");
    node1.setNext(&node2);
    node2.setNext(&node3);
    node3.setNext(&node1);

    node1.setPrevious(&node3);
    node2.setPrevious(&node1);
    node3.setPrevious(&node2);

    node1.setEnd(false);
    node2.setEnd(false);
    node3.setEnd(true);

    node<T> node4(&node2,&node1, false,"chipopotam");
    node<T> node5(node4);
    node5.getNext();

    return true;
}

static bool iteratorBasic(){
    List<T> list1;
    ASSERT_NO_THROW(list1.insert("Shlomo"));
    List<T>::Iterator iterator1 = list1.end();
    ASSERT_THROWS(mtm::ListExceptions::ElementNotFound,*iterator1);
    iterator1=list1.begin();

    List<T> list2;
    ASSERT_NO_THROW(list2.insert("Shlomo"));
    List<T>::Iterator iterator2 = list2.begin();
    ASSERT_NOT_EQUAL(iterator2,iterator1);

    ASSERT_THROWS(mtm::ListExceptions::ElementNotFound,list1.remove(iterator2));
    iterator2=list2.end();
    ASSERT_THROWS(mtm::ListExceptions::ElementNotFound,list2.remove(iterator2));
    iterator2=list2.begin();
    ASSERT_NO_THROW(list2.remove(iterator2));
    iterator2=list2.begin();
    ASSERT_THROWS(mtm::ListExceptions::ElementNotFound,list2.remove(iterator2));
    List<T> list3;
    List<T>::Iterator iterator3 = list3.begin();
    ASSERT_THROWS(mtm::ListExceptions::ElementNotFound,list3.remove(iterator3));

    return true;
}

static bool listBasic(){
    List<T> list1;
    ASSERT_NO_THROW(list1.insert("ahmad"));
    ASSERT_NO_THROW(list1.insert("allah"));
    assert(list1.getSize()==2);
    ASSERT_NO_THROW(list1.insert("davidof"));
    assert(list1.getSize()==3);
    List<T>::Iterator it=list1.begin();
    List<T>::Iterator it2(it);
    const node<T> node1=it2.getNode();
    ASSERT_EQUALS(it2,it);
    List<T>::Iterator it3=list1.end();
    ASSERT_NOT_EQUAL(it3,it);
    T var1=*it++;
    T var2=*it;
    --it;
    T var3=*it;
    ASSERT_EQUALS(var3,var1);
    it++;
    T var4=*--it;
    ASSERT_EQUALS(var4,var3);
    it=list1.end();
    it=it2;
    it=it;
    return true;
}

static bool listInsertion(){
    List<T> list1;
    ASSERT_NO_THROW(list1.insert("aaaaa"));
    ASSERT_NO_THROW(list1.insert("bbbbb"));
    ASSERT_NO_THROW(list1.insert("ccccc"));
    List<T>::Iterator iterator=list1.begin();
    iterator++;
    List<T>::Iterator iterator2=list1.begin();
    iterator2++;
    if(iterator==iterator2)
        iterator2--;
    if (iterator2!=iterator)
        iterator--;
    List<T> list2;
    ASSERT_NO_THROW(list2.insert("aaaaa"));
    ASSERT_NO_THROW(list2.insert("bbbbb"));
    ASSERT_NO_THROW(list2.insert("ccccc"));
    ASSERT_EQUALS(list1,list2);
    List<T>::Iterator iterator3=list2.begin();
    if(iterator3==iterator)
        iterator2++;
    ASSERT_NO_THROW(list1.remove(iterator));
    iterator=list1.begin();
    iterator++;
    ASSERT_NO_THROW(list1.remove(iterator));
    ASSERT_NOT_EQUAL(list1,list2);
    std::cout<<"double yay"<<std::endl;
    return true;
}

static bool listAdvanced(){
    List<T> list;
    ASSERT_NO_THROW(list.insert("avraham"));
    List<T>::Iterator iterator1=list.begin();
    List<T>::Iterator iterator2=list.begin();
    ASSERT_NO_THROW(list.insert("Gury"));
    ASSERT_NO_THROW(list.insert("Alfy",iterator1));
    iterator1 =(++list.begin());
    ASSERT_NO_THROW(list.insert("Dolev Shifris",iterator1));
    HasSameName IsGury("Gury");
    const HasSameName& Predicate = IsGury;
    ASSERT_NO_THROW(iterator2=list.find(Predicate));
    ASSERT_EQUALS("Gury",iterator2.getNode().getInfo());
    const StringIsSmaller compare;
    ASSERT_NO_THROW(list.sort(compare));
    iterator1= list.begin();
    checkContent(iterator1);
    List<T> list2;
    list2=list;
    iterator2= list2.begin();
    checkContent(iterator2);
    List<T> list3(list2);
    List<T>::Iterator iterator3= list3.begin();
    checkContent(iterator3);
    List<T> list4;
    list3=list4;
    list3=list2;
    return true;
}

int list_tests(){
    RUN_TEST(nodeBasic);
    RUN_TEST(iteratorBasic);
    RUN_TEST(listBasic);
    RUN_TEST(listInsertion);
    RUN_TEST(listAdvanced);
    return 0;
}





