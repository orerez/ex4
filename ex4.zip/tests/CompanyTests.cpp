#include <ostream>
#include <iostream>
//
// Created by orerez on 02/07/2017.
//
#include <iostream>
#include <cstring>
#include "../mtmtest.h"
#include "../EscapeRoomWrapper.h"
#include "../Enigma.h"
#include "../ScaryRoom.h"
#include "../KidsRoom.h"
#include "../Company.h"
#include "../Exceptions.h"

using namespace mtm::escaperoom;
typedef set<EscapeRoomWrapper*>::iterator Iterator;


static void PrintByType(set<EscapeRoomWrapper*> rooms_set1){
    std::cout << std::endl;
    Iterator iterator1 = rooms_set1.begin();
    int size1 = (int)rooms_set1.size();
    for (int i =0; i<size1; ++i) {
        EscapeRoomWrapper* ptrWrapper = *iterator1;
        EscapeRoomWrapper roomWrapper = *ptrWrapper;
        const ScaryRoom* scary = dynamic_cast<const ScaryRoom*>(*iterator1);
        const KidsRoom* kids = dynamic_cast<const KidsRoom*>(*iterator1);
        if(scary!= nullptr)
            std::cout<< i+1 <<") "<< *scary <<std::endl;
        else if(kids!= nullptr){
            std::cout << i+1<< ") "<<*kids << std::endl;
        } else {
            std::cout<< i+1<< ") "<< roomWrapper << std::endl;
        }
        iterator1++;
    }
}

static bool companyBaseFunctions(){
    Company company1("EscapeHere","054232211");
    ASSERT_NO_THROW(company1.createRoom((char*)"anubis",60,5,3));
    Company company2("bla","blabla");
    ASSERT_NO_THROW(company2 = company1);
    ASSERT_NO_THROW(company1.createKidsRoom((char*)"toyLand",80,3,2,5));
    ASSERT_NO_THROW(company2.createScaryRoom((char*)"elemSt",55,8,4,16,6));
    set<EscapeRoomWrapper*> rooms_set1 = company1.getAllRooms();
    set<EscapeRoomWrapper*> rooms_set2 = company2.getAllRooms();
    PrintByType(rooms_set1);
    PrintByType(rooms_set2);
    return true;
}

static bool AddRemoveEnigma(Company company1, Company company2){
    set<EscapeRoomWrapper*> rooms_set1 = company1.getAllRooms();
    set<EscapeRoomWrapper*> rooms_set2 = company2.getAllRooms();
    set<string> elements;
    Enigma LegoLand("LegoLand",(Difficulty)3);
    Enigma Baskerwill("Baskerwill",(Difficulty)5,0,elements);
    ASSERT_NO_THROW(rooms_set1 = company1.getAllRooms());
    ASSERT_NO_THROW(company1.addEnigma(*(*(rooms_set1.begin())),LegoLand));
    ASSERT_NO_THROW(company1.addEnigma(*(*(++rooms_set1.begin())),Baskerwill));
    ASSERT_NO_THROW(rooms_set1=company1.getAllRooms());
    Iterator iterator = rooms_set1.begin();
    std::vector<Enigma>& enigmas = (*iterator)->getAllEnigmas();
    ASSERT_EQUALS(LegoLand,enigmas[0]);
    iterator++;
    std::vector<Enigma>& enigmas2 = (*iterator)->getAllEnigmas();
    ASSERT_EQUALS(Baskerwill,enigmas2[0]);
    ASSERT_EQUALS(1,enigmas2.size());
    ASSERT_NO_THROW(company1.removeEnigma(*(*iterator),Baskerwill));
    enigmas2 = (*iterator)->getAllEnigmas();
    ASSERT_EQUALS(0,enigmas2.size());
    ASSERT_THROWS(CompanyRoomEnigmaNotFoundException,company1.removeEnigma(*(*(--iterator)),Baskerwill));
    ASSERT_THROWS(CompanyRoomHasNoEnigmasException,company1.removeEnigma(*(*(++iterator)),Baskerwill));
    return true;
}

static bool AddRemoveItem(Company company1, Company company2){
    Enigma LegoLand("LegoLand",(Difficulty)3);
    Enigma Spear("Spear",(Difficulty)2);
    Enigma Tuty("FruityTuty",(Difficulty)2);

    set<EscapeRoomWrapper*> rooms_set1 = company1.getAllRooms();
    set<EscapeRoomWrapper*> rooms_set2 = company2.getAllRooms();
    ASSERT_NO_THROW(company1.addEnigma(*(*(rooms_set1.begin())),LegoLand));
    ASSERT_NO_THROW(company2.addEnigma( (*(*(rooms_set2.begin()))),Spear));
    ASSERT_NO_THROW(company1.addEnigma( (*(*(rooms_set1.begin()))),Tuty));

    rooms_set1 = company1.getAllRooms();
    rooms_set2 = company2.getAllRooms();
    Iterator iterator1 = rooms_set1.begin();
    Iterator iterator2 = rooms_set2.begin();
    std::vector<Enigma>& enigmasVector1 = (*(*iterator1)).getAllEnigmas();
    ASSERT_EQUALS(0,enigmasVector1[0].getNumOfElements());

    ASSERT_NO_THROW(company1.addItem((*(*iterator1)),enigmasVector1[0],"Gerbil"));
    ASSERT_NO_THROW(company1.addItem((*(*iterator1)),enigmasVector1[0],"Chinchila"));
    ASSERT_NO_THROW(company1.addItem((*(*iterator1)),enigmasVector1[0],"Chin"));
    enigmasVector1 = (*(*iterator1)).getAllEnigmas();
    ASSERT_EQUALS(3,enigmasVector1[0].getNumOfElements());

    ASSERT_NO_THROW(company1.removeItem((*(*iterator1)),enigmasVector1[0],"Chinchila"));
    enigmasVector1 = (*(*iterator1)).getAllEnigmas();
    ASSERT_EQUALS(2,enigmasVector1[0].getNumOfElements());

    ASSERT_THROWS(CompanyRoomNotFoundException,company1.addItem((*(*iterator2)),enigmasVector1[0],"Nambsatsul"));
    ASSERT_THROWS(CompanyRoomEnigmaNotFoundException, company1.addItem((*(*iterator1)),Spear,"Nambsatsul"));
    ASSERT_THROWS(CompanyRoomEnigmaHasNoElementsException,company1.removeItem((*(*iterator1)),enigmasVector1[1],"Chin"));
    ASSERT_THROWS(CompanyRoomEnigmaElementNotFoundException,
                  company1.removeItem((*(*iterator1)),enigmasVector1[0],"Chinchila"));
    ASSERT_THROWS(CompanyRoomEnigmaNotFoundException,company1.removeItem((*(*iterator1)),Spear,"Chinchila"));
    ASSERT_THROWS(CompanyRoomNotFoundException,company1.removeItem((*(*iterator2)),enigmasVector1[0],"Gerbil"));

    return true;
}

static bool companyAddRemoveFunctions(){
    Company company1("Escape-oh","053666667");
    ASSERT_NO_THROW(company1.createRoom((char*)"AlexanderMokadon",60,5,3));
    Company company2("Freddy","034342678");
    ASSERT_NO_THROW(company2 = company1);
    ASSERT_NO_THROW(company1.createKidsRoom((char*)"toyLand",80,3,2,5));
    ASSERT_NO_THROW(company1.createRoom((char*)"Sherlock",65,7,4));
    ASSERT_NO_THROW(company2.createKidsRoom((char*)"Marshmello",120,6,3,9));
    ASSERT_NO_THROW(company2.createScaryRoom((char*)"elemSt",55,8,4,16,6));
    EscapeRoomWrapper Holand((char*)"Guttentag",50,7,8);
    EscapeRoomWrapper ElemSt2((char*)"elemSt",55,8,4);

    set<EscapeRoomWrapper*> rooms_set1 = company1.getAllRooms();
    set<EscapeRoomWrapper*> rooms_set2 = company2.getAllRooms();

    PrintByType(rooms_set1);
    PrintByType(rooms_set2);

    ASSERT_NO_THROW(company1.removeRoom(*(*(rooms_set1.begin()))));
    PrintByType( company1.getAllRooms());
    ASSERT_NO_THROW(company2.removeRoom(ElemSt2));
    ASSERT_THROWS(CompanyRoomNotFoundException, company2.removeRoom(ElemSt2));
    PrintByType(company2.getAllRooms());

    AddRemoveEnigma(company1,company2);
    AddRemoveItem(company1,company2);
    return true;
}

static bool companyGetPrintFunctions(){
    Company company1("Escape-oh","053666667");
    ASSERT_NO_THROW(company1.createRoom((char*)"AlexanderMokadon",60,5,3));
    Company company2("Freddy","034342678");
    ASSERT_NO_THROW(company2 = company1);
    ASSERT_NO_THROW(company2.createScaryRoom((char*)"Alien",40,3,5,15,5));
    ASSERT_NO_THROW(company1.createKidsRoom((char*)"toyLand",80,3,2,5));
    ASSERT_NO_THROW(company1.createRoom((char*)"Sherlock",65,7,4));
    ASSERT_NO_THROW(company2.createKidsRoom((char*)"Marshmello",120,6,3,9));
    ASSERT_NO_THROW(company2.createScaryRoom((char*)"elemSt",55,8,4,16,6));
    ASSERT_NO_THROW(company2.createScaryRoom((char*)"Jaws",67,6,7,18,10));

    set<EscapeRoomWrapper*> scary_room_company2 = company2.getAllRoomsByType(mtm::escaperoom::SCARY_ROOM);
    set<EscapeRoomWrapper*> kids_room_company1 = company1.getAllRoomsByType(mtm::escaperoom::KIDS_ROOM);
    set<EscapeRoomWrapper*> base_room_company1 = company1.getAllRoomsByType(mtm::escaperoom::BASE_ROOM);
    PrintByType(scary_room_company2);
    PrintByType(kids_room_company1);
    PrintByType(base_room_company1);

    ASSERT_THROWS(CompanyRoomNotFoundException,company1.getRoomByName("Alien"));
    EscapeRoomWrapper* roomWrapper = company2.getRoomByName("Alien");
    ASSERT_EQUALS(*(*scary_room_company2.begin()),*roomWrapper);

    std::set<string>Items;
    string hello="hi";
    ASSERT_NO_THROW(Items.insert(hello));
    const std::set<string>& Items1 =Items;

    set<EscapeRoomWrapper*> rooms_set1 = company1.getAllRooms();
    set<EscapeRoomWrapper*> rooms_set2 = company2.getAllRooms();

    Enigma LegoLand("LegoLand",(Difficulty)3);
    Enigma Tuty("FruityTuty",(Difficulty)2);
    Enigma Baskerwill("Baskerwill",(Difficulty)5,1,Items1);
    Enigma Freddy("Freddy",(Difficulty)1);

    rooms_set1 = company1.getAllRooms();
    ASSERT_NO_THROW(company1.addEnigma(*(*(rooms_set1.begin())),LegoLand));
    ASSERT_NO_THROW(company1.addEnigma(*(*(rooms_set1.begin())),Tuty));
    ASSERT_NO_THROW(company1.addEnigma(*(*(++rooms_set1.begin())),Baskerwill));
    ASSERT_NO_THROW(company2.addEnigma(*(*(++rooms_set2.begin())),Freddy));

    Iterator iterator1 = rooms_set1.begin();
    std::vector<Enigma>& enigmasVector1 = (*(*iterator1)).getAllEnigmas();
    ASSERT_NO_THROW(company1.addItem((*(*iterator1)),enigmasVector1[0],"LegoBoy"));
    ASSERT_NO_THROW(company1.addItem((*(*iterator1)),enigmasVector1[0],"LegoGuy"));
    ASSERT_NO_THROW(company1.addItem((*(*iterator1)),enigmasVector1[0],"LegoGirl"));

    std::cout<<std::endl;
    std::cout<<company1<<std::endl;
    std::cout<<std::endl;
    std::cout<<company2<<std::endl;

    return true;
}


int main() {
    RUN_TEST(companyBaseFunctions);
    RUN_TEST(companyAddRemoveFunctions);
    RUN_TEST(companyGetPrintFunctions);
}