//
// Created by orerez on 01/07/2017.
//


#include "../mtmtest.h"
#include "../EscapeRoomWrapper.h"
#include "../Exceptions.h"
#include "../KidsRoom.h"

using namespace mtm::escaperoom;

static bool kidsBaseFunctions(){
    KidsRoom room=KidsRoom((char*)"firstRoom",50,5,4,7);
    ASSERT_NO_THROW(room.setNewAgeLimit(3));
    ASSERT_THROWS(mtm::escaperoom::KidsRoomIllegalAgeLimit,room.setNewAgeLimit(-3));
    return true;
}
int KidsTests(){
    RUN_TEST(kidsBaseFunctions);
    return 0;
}