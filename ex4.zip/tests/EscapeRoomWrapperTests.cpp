//
// Created by orerez on 01/07/2017.
//


#include <assert.h>
#include "../Exceptions.h"
#include "../EscapeRoomWrapper.h"
#include "../mtmtest.h"

using namespace mtm::escaperoom;

typedef string T;

typedef set<EscapeRoomWrapper*>::iterator Iterator;

static bool escaperoomWrapperBasicFunctions(){
    EscapeRoomWrapper room=EscapeRoomWrapper((char*)"firstRoom",50,5,4);
    std::cout<<room<<std::endl;
    return true;
}

static bool escaperoomWrapperVectorFunctions(){
    EscapeRoomWrapper room=EscapeRoomWrapper((char*)"roomName",50,4,5);
    Enigma enigma("findExit",(Difficulty)6);
    Enigma enigma2("openDoor",(Difficulty)8);
    room.addEnigma(enigma);
    room.addEnigma(enigma2);
    Enigma hardest = room.getHardestEnigma();
    ASSERT_EQUALS(hardest,enigma2);
    std::vector<Enigma>& roomEnigmas=room.getAllEnigmas();
    if(roomEnigmas.size()!=2 || roomEnigmas[0]!=enigma || roomEnigmas[1]!=enigma2)
        return false;
    ASSERT_NO_THROW(room.removeEnigma(enigma));
    if(roomEnigmas.size()!=1 || roomEnigmas[0]!=enigma2)
        return false;
    ASSERT_THROWS(EscapeRoomEnigmaNotFoundException, room.removeEnigma(enigma));
    ASSERT_NO_THROW(room.removeEnigma(enigma2));
    if(!roomEnigmas.empty())
        return false;
    ASSERT_THROWS(EscapeRoomNoEnigmasException, room.removeEnigma(enigma2));
    ASSERT_THROWS(EscapeRoomNoEnigmasException,room.getHardestEnigma());
    return true;
}

static bool getFunctions(){
    EscapeRoomWrapper room=EscapeRoomWrapper((char*)"roomName",50,4,5);
    ASSERT_EQUALS((std::string)"roomName",room.getName());
    ASSERT_EQUALS(5,room.getMaxParticipants());
    ASSERT_EQUALS(50,room.getMaxTime());
    ASSERT_EQUALS(4,room.level());

    ASSERT_NO_THROW(room.rate(5));
    ASSERT_NO_THROW(room.rate(4));
    ASSERT_NO_THROW(room.rate(3));
    ASSERT_NO_THROW(room.rate(2));

    ASSERT_EQUALS(3.5,room.getRate());

    return true;
}

static bool constructors(){
    EscapeRoomWrapper room_A=EscapeRoomWrapper((char*)"Escapus",4);
    EscapeRoomWrapper room_B=EscapeRoomWrapper(room_A);
    EscapeRoomWrapper room_C=EscapeRoomWrapper((char*)"chief",3);
    room_C=room_B;
    std::cout<<"computer printing 3 rooms which built from different constructors\n"
             <<room_A<<room_B<<room_C<<std::endl;
    return true;
}

static bool powerTests(){
    EscapeRoomWrapper room_A((char*)"thisIsName",6);
    EscapeRoomWrapper room_B((char*)"thisIs",50,5,6);
    EscapeRoomWrapper room_C((char*)"thisIs",40,5,6);
    EscapeRoomWrapper room_D((char*)"thisIs",30,5,6);
    EscapeRoomWrapper room_E((char*)"thisIs",20,5,6);
    EscapeRoomWrapper room_F((char*)"thisIs",10,5,6);
    EscapeRoomWrapper room_G((char*)"thisIs",10,4,6);
    EscapeRoomWrapper room_H((char*)"thisIs",11,3,6);
    if(room_A<room_B)
        return false;
    if(room_B<room_C||room_C<room_D||room_D<room_E||
       room_E<room_F||room_F<room_G||room_G<room_H)
        return false;
    if(!(room_A!=room_B && room_B!=room_E && room_F==room_F))
        return false;
    assert(true);
    return true;
}

int ERW_Tests(){
    RUN_TEST(escaperoomWrapperBasicFunctions);
    RUN_TEST(escaperoomWrapperVectorFunctions);
    RUN_TEST(getFunctions);
    RUN_TEST(constructors);
    RUN_TEST(powerTests);
    return 0;
}