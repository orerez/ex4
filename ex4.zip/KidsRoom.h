//
// Created by orerez on 25/06/2017.
//

#ifndef NEW_EX4_KIDSROOM_H
#define NEW_EX4_KIDSROOM_H

#include "EscapeRoomWrapper.h"

namespace mtm {
    namespace escaperoom {
        class KidsRoom : public mtm::escaperoom::EscapeRoomWrapper {
            int ageLimit;
        public:

            // Constructs a new kids Escape Room with the specified data.
            //
            // @param name : the name of the escape room.
            // @param escapeTime : the maximal escape time allowed in the room.
            // @param level : the level of the escape room.
            // @param maxParticipants : the maximal participants allowed in the room.
            // @param ageLimit : The maximal age allowing entrance to the room.
            // @throws EscapeRoomMemoryProblemException in case of creation failure.
            // The rest of the room's data is initialized as described in the exercise sheet.
            //
            KidsRoom(char *name, const int &escapeTime, const int &level, const int &maxParticipants,
                     const int &ageLimit) :
                    EscapeRoomWrapper(name, escapeTime, level, maxParticipants),
                    ageLimit(ageLimit) {}

            ~KidsRoom() = default;

            //the method changes the age limit according to the limit given.
            //
            // @param limit the new age limit of the room.
            //
            void setNewAgeLimit(const int &limit);

            // returns the room's age limit.
            //
            // @throws KidsRoomIllegalAgeLimit if age limit is less then 0;
            // @return the room age limit
            //
            int getAgeLimit() const;

            //Function returns the type of the EscapeRoom.
            //
            mtm::escaperoom::RoomType getType() const override;

            friend std::ostream &operator<<(std::ostream &output, const mtm::escaperoom::KidsRoom &room);


        };

        std::ostream &operator<<(std::ostream &output, const mtm::escaperoom::KidsRoom &room);

    }
}




#endif //NEW_EX4_KIDSROOM_H
