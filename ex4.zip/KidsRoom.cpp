//
// Created by orerez on 25/06/2017.
//

#include "KidsRoom.h"
#include "Exceptions.h"

using mtm::escaperoom::KidsRoom;

void KidsRoom::setNewAgeLimit(const int &limit) {
    if (limit < 0) {
        mtm::escaperoom::KidsRoomIllegalAgeLimit illegalAgeLimit;
        throw illegalAgeLimit;
    }
    this->ageLimit = limit;
}

int KidsRoom::getAgeLimit() const {
    return this->ageLimit;
}

mtm::escaperoom::RoomType KidsRoom::getType() const {
    return KIDS_ROOM;
}

namespace mtm {
    namespace escaperoom {
        std::ostream &operator<<(std::ostream &output, const KidsRoom &room) {
            output << "Kids Room: " << room.getName() << " (" << room.getMaxTime() << "/" << room.level()
                   << "/" << room.getMaxParticipants() << "/" << room.getAgeLimit() << ")";
            return output;
        }
    }
}